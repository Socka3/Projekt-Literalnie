
Słownik SJP.PL - wersja do gier słownych

Słownik udostępniany na licencjach GPL 2 oraz
Creative Commons Attribution 4.0 International

https://sjp.pl

